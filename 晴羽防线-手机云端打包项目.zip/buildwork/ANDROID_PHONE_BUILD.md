# 只用安卓手机生成 APK（云端构建）

你不需要 Windows 电脑，但需要一个 GitHub 账号，并用手机浏览器操作。GitHub Actions 在云端编译 Android APK。

## 操作方式
1. 在手机浏览器打开 GitHub 并登录，创建一个新的 Private 仓库。
2. 将本 ZIP 解压后，把项目文件上传到仓库根目录（GitHub 网页端可通过 Add file 上传；文件较多时建议使用 GitHub 手机网页的上传功能分批上传）。
3. 上传完成后，打开仓库的 Actions 页面，选择工作流 `Build Android APK` 并运行。
4. 工作流成功后，在该次运行页面的 Artifacts 区域下载 `qingyu-debug-apk`，解压即可得到 APK。

注意：云端构建需要仓库内有完整项目文件。首次上传/构建可能需要几步手机操作。此项目 APK 目前尚未在本环境编译验证。
