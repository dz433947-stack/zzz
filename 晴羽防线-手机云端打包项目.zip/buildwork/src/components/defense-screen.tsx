import { useEffect, useRef, useState } from "react";
import { Coins, Heart, Pause, Play } from "lucide-react";
import { AIM_LABEL, TOWER_LIST, TOWERS, type TowerKind } from "@/game/data";
import { unlockAudio } from "@/game/audio";
import { DefenseGame, loadArt, type Hud } from "@/game/defense";

function sameHud(a: Hud | null, b: Hud): boolean {
  if (!a) return false;
  return (
    a.phase === b.phase &&
    a.lives === b.lives &&
    a.gold === b.gold &&
    a.wave === b.wave &&
    a.prepLeft === b.prepLeft &&
    a.earlyBonus === b.earlyBonus &&
    a.enemiesLeft === b.enemiesLeft &&
    a.kills === b.kills &&
    a.goldEarned === b.goldEarned &&
    a.armed === b.armed &&
    a.toast === b.toast &&
    a.bestWave === b.bestWave &&
    a.selected?.id === b.selected?.id &&
    a.selected?.dmgRank === b.selected?.dmgRank &&
    a.selected?.rateRank === b.selected?.rateRank &&
    a.selected?.aim === b.selected?.aim &&
    a.selected?.refund === b.selected?.refund
  );
}

export function DefenseScreen() {
  const wrapRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const gameRef = useRef<DefenseGame | null>(null);
  if (!gameRef.current) gameRef.current = new DefenseGame();
  const [hud, setHud] = useState<Hud>(() => gameRef.current.hud());

  useEffect(() => {
    const game = gameRef.current;
    if (!game) return;
    const canvas = canvasRef.current;
    const wrap = wrapRef.current;
    if (!canvas || !wrap) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    let dead = false;
    void loadArt().then((art) => {
      if (!dead) game.attach(art);
    });

    const resize = () => {
      const rect = wrap.getBoundingClientRect();
      const dpr = Math.min(2, window.devicePixelRatio || 1);
      canvas.width = Math.max(1, Math.floor(rect.width * dpr));
      canvas.height = Math.max(1, Math.floor(rect.height * dpr));
      game.resize(rect.width, rect.height, dpr);
    };
    resize();
    const observer = new ResizeObserver(resize);
    observer.observe(wrap);

    let frame = 0;
    let last = performance.now();
    let acc = 0;
    let hudClock = 0;
    const step = 1 / 60;
    const loop = (now: number) => {
      frame = requestAnimationFrame(loop);
      const dt = Math.min(0.05, (now - last) / 1000);
      last = now;
      acc += dt;
      let steps = 0;
      while (acc >= step && steps < 5) {
        game.tick(step);
        acc -= step;
        steps += 1;
      }
      ctx.setTransform(game.dpr, 0, 0, game.dpr, 0, 0);
      game.draw(ctx);
      hudClock += dt;
      if (hudClock >= 0.1) {
        hudClock = 0;
        const next = game.hud();
        setHud((prev) => (sameHud(prev, next) ? prev : next));
      }
    };
    frame = requestAnimationFrame(loop);

    const onVis = () => {
      if (document.visibilityState === "visible") last = performance.now();
    };
    document.addEventListener("visibilitychange", onVis);

    const onKey = (event: KeyboardEvent) => {
      if (event.repeat) return;
      const target = event.target as HTMLElement | null;
      if (target && (target.tagName === "INPUT" || target.tagName === "TEXTAREA")) return;
      if (event.code === "Digit1") game.arm("bamboo");
      else if (event.code === "Digit2") game.arm("cracker");
      else if (event.code === "Digit3") game.arm("jade");
      else if (event.code === "Digit4") game.arm("lotus");
      else if (event.code === "Space") {
        event.preventDefault();
        if (game.phase === "title") {
          unlockAudio();
          game.begin();
        } else game.startWave();
      } else if (event.code === "Escape") game.clearSelection();
      else if (event.code === "KeyP") game.togglePause();
      else return;
      setHud(game.hud());
    };
    window.addEventListener("keydown", onKey);

    return () => {
      dead = true;
      cancelAnimationFrame(frame);
      observer.disconnect();
      document.removeEventListener("visibilitychange", onVis);
      window.removeEventListener("keydown", onKey);
    };
  }, []);

  const game = gameRef.current;
  const sync = () => setHud(game.hud());
  const point = (event: React.PointerEvent<HTMLCanvasElement>) => {
    const rect = event.currentTarget.getBoundingClientRect();
    return { x: event.clientX - rect.left, y: event.clientY - rect.top };
  };

  const playing = hud.phase === "prep" || hud.phase === "combat" || hud.phase === "paused";

  return (
    <main className="app-shell">
      <section className="stage" aria-label="晴羽防线">
        <header className="topbar">
          <div className="brand">晴羽防线</div>
          {playing ? (
            <>
              <div className={`stat is-life${hud.lives <= 5 ? " is-low" : ""}`} aria-label={`剩余生命 ${hud.lives}`}>
                <Heart aria-hidden />
                <b>{hud.lives}</b>
              </div>
              <div className="stat is-gold" aria-label={`当前金币 ${hud.gold}`}>
                <Coins aria-hidden />
                <b>{hud.gold}</b>
              </div>
              <div className="stat" aria-label={`第 ${hud.wave} 波，共 ${hud.waveCount} 波`}>
                <b>
                  {hud.wave}/{hud.waveCount}波
                </b>
              </div>
              <button
                type="button"
                className="icon-btn"
                aria-label={hud.phase === "paused" ? "继续" : "暂停"}
                onClick={() => {
                  game.togglePause();
                  sync();
                }}
              >
                {hud.phase === "paused" ? <Play aria-hidden /> : <Pause aria-hidden />}
              </button>
            </>
          ) : (
            <div className="stat" aria-label={`最远纪录第 ${hud.bestWave} 波`}>
              <b>{hud.bestWave > 0 ? `纪录 ${hud.bestWave} 波` : "十二波"}</b>
            </div>
          )}
        </header>

        <div className="board" ref={wrapRef}>
          <canvas
            ref={canvasRef}
            aria-label="田埂战场"
            onContextMenu={(event) => event.preventDefault()}
            onPointerDown={(event) => {
              unlockAudio();
              const p = point(event);
              game.pointerDown(p.x, p.y);
            }}
            onPointerMove={(event) => {
              const p = point(event);
              game.hover(p.x, p.y);
            }}
            onPointerUp={(event) => {
              const p = point(event);
              game.pointerUp(p.x, p.y);
              sync();
            }}
            onPointerLeave={() => game.hover(-1, -1)}
          />
          {hud.toast ? (
            <div className="toast" role="status">
              {hud.toast}
            </div>
          ) : null}
        </div>

        <footer className="dock">
          <div className="call">
            {hud.phase === "prep" || (hud.phase === "paused" && hud.prepLeft > 0 && hud.enemiesLeft === 0) ? (
              <button
                type="button"
                className="call-btn"
                onClick={() => {
                  unlockAudio();
                  if (hud.phase === "paused") game.togglePause();
                  game.startWave();
                  sync();
                }}
              >
                出兵 · 还剩 {hud.prepLeft}s
                {hud.earlyBonus > 0 ? ` · 提前 +${hud.earlyBonus}` : ""}
              </button>
            ) : (
              <div className="call-status">
                <img src="/sprites/pig/down-1.png" alt="" />
                <div>
                  <strong>孙晴羽</strong>
                  <span>
                    {hud.phase === "combat"
                      ? `${hud.waveName} · 场上还剩 ${hud.enemiesLeft}`
                      : "沿田埂往村口闯"}
                  </span>
                </div>
              </div>
            )}
          </div>

          {hud.selected ? (
            <TowerSheet
              view={hud.selected}
              gold={hud.gold}
              onAim={() => {
                game.cycleAim();
                sync();
              }}
              onUpgrade={(path) => {
                game.upgrade(path);
                sync();
              }}
              onSell={() => {
                game.sell();
                sync();
              }}
              onBack={() => {
                game.clearSelection();
                sync();
              }}
            />
          ) : (
            <>
              <div className="cards">
                {TOWER_LIST.map((kind) => (
                  <TowerButton
                    key={kind}
                    kind={kind}
                    armed={hud.armed === kind}
                    disabled={!playing || hud.gold < TOWERS[kind].cost}
                    onClick={() => {
                      unlockAudio();
                      game.arm(kind);
                      sync();
                    }}
                  />
                ))}
              </div>
              <p className="hint">四种塔射程和价钱都不一样。点已放下的塔，能分开升级伤害和射速。</p>
            </>
          )}
        </footer>

        {hud.phase === "title" ? (
          <div className="overlay">
            <div className="sheet">
              <p className="kicker">田埂塔防</p>
              <h1>晴羽防线</h1>
              <p className="lede">一窝名叫孙晴羽的猪正沿着田埂往村口跑。把塔立在草地上，靠击杀掉的金币撑过十二波。</p>
              <div className="hero-row">
                <img src="/sprites/pig/down-2.png" alt="孙晴羽，一只系着红绳的猪" />
                <ul className="rules">
                  <li>点选塔，再点发光的草地</li>
                  <li>漏进村口就扣生命</li>
                  <li>伤害和射速分开升级</li>
                </ul>
              </div>
              <div className="tower-preview" aria-hidden>
                {TOWER_LIST.map((kind) => (
                  <img key={kind} src={TOWERS[kind].frame} alt="" />
                ))}
              </div>
              {hud.bestWave > 0 ? <p className="fine best">最远到达第 {hud.bestWave} 波</p> : null}
              <button
                type="button"
                className="btn-primary"
                onClick={() => {
                  unlockAudio();
                  game.begin();
                  sync();
                }}
              >
                开始守城
              </button>
            </div>
          </div>
        ) : null}

        {hud.phase === "victory" || hud.phase === "defeat" ? (
          <div className="overlay">
            <div className="sheet">
              <p className="kicker">{hud.phase === "victory" ? "守住了" : "失守"}</p>
              <h1>{hud.phase === "victory" ? "田埂保住了" : "村口失守"}</h1>
              <p className="lede">
                {hud.phase === "victory"
                  ? "十二波孙晴羽都被拦在田埂上。"
                  : "孙晴羽冲进了村口。再布一阵试试。"}
              </p>
              <div className="stats">
                <div>
                  <span className="fine">剩余生命</span>
                  <b>{hud.lives}</b>
                </div>
                <div>
                  <span className="fine">当前金币</span>
                  <b>{hud.gold}</b>
                </div>
                <div>
                  <span className="fine">到达波次</span>
                  <b>
                    {hud.phase === "victory" ? hud.waveCount : hud.wave}/{hud.waveCount}
                  </b>
                </div>
                <div>
                  <span className="fine">击杀</span>
                  <b>{hud.kills}</b>
                </div>
              </div>
              <button
                type="button"
                className="btn-primary"
                onClick={() => {
                  unlockAudio();
                  game.restart();
                  sync();
                }}
              >
                再来一局
              </button>
              <button
                type="button"
                className="btn-ghost"
                onClick={() => {
                  game.toTitle();
                  sync();
                }}
              >
                回标题
              </button>
            </div>
          </div>
        ) : null}

        {hud.phase === "paused" ? (
          <div className="overlay">
            <div className="sheet">
              <p className="kicker">暂停</p>
              <h1>先歇口气</h1>
              <p className="lede">
                生命 {hud.lives} · 金币 {hud.gold} · 第 {hud.wave} 波
              </p>
              <button
                type="button"
                className="btn-primary"
                onClick={() => {
                  game.togglePause();
                  sync();
                }}
              >
                继续
              </button>
              <button
                type="button"
                className="btn-ghost"
                onClick={() => {
                  game.restart();
                  sync();
                }}
              >
                再来一局
              </button>
            </div>
          </div>
        ) : null}
      </section>
    </main>
  );
}

function TowerButton({
  kind,
  armed,
  disabled,
  onClick,
}: {
  kind: TowerKind;
  armed: boolean;
  disabled: boolean;
  onClick: () => void;
}) {
  const def = TOWERS[kind];
  return (
    <button
      type="button"
      className={`tower-btn${armed ? " is-armed" : ""}`}
      aria-pressed={armed}
      disabled={disabled && !armed}
      onClick={onClick}
    >
      <img src={def.frame} alt="" />
      <b>{def.name}</b>
      <em>
        {def.reach} · {def.cost}
      </em>
    </button>
  );
}

function TowerSheet({
  view,
  gold,
  onAim,
  onUpgrade,
  onSell,
  onBack,
}: {
  view: Hud["selected"];
  gold: number;
  onAim: () => void;
  onUpgrade: (path: "damage" | "rate") => void;
  onSell: () => void;
  onBack: () => void;
}) {
  if (!view) return null;
  const frame = TOWERS[view.kind].frame;
  return (
    <div className="detail">
      <img className="portrait" src={frame} alt="" />
      <div>
        <h2>{view.name}</h2>
        <p className="meta">
          {view.reach} · 范围 {view.range.toFixed(1)} 格
        </p>
      </div>
      <p className="meta">{view.blurb}</p>
      <div className="upgrades">
        <button
          type="button"
          className="upgrade"
          disabled={view.dmgCost === null || gold < (view.dmgCost ?? 0)}
          onClick={() => onUpgrade("damage")}
        >
          <b>
            伤害 Lv.{view.dmgRank + 1}
            {view.nextDamage !== null ? ` → ${view.nextDamage}` : " 已满"}
          </b>
          <small>{view.dmgCost === null ? "这条路到头了" : `${view.damage} 点 · ${view.dmgCost} 金`}</small>
        </button>
        <button
          type="button"
          className="upgrade"
          disabled={view.rateCost === null || gold < (view.rateCost ?? 0)}
          onClick={() => onUpgrade("rate")}
        >
          <b>
            射速 Lv.{view.rateRank + 1}
            {view.nextRate !== null ? ` → ${view.nextRate.toFixed(1)}` : " 已满"}
          </b>
          <small>{view.rateCost === null ? "这条路到头了" : `${view.rate.toFixed(1)} 发/秒 · ${view.rateCost} 金`}</small>
        </button>
      </div>
      <div className="row-actions">
        <button type="button" className="btn-ghost" onClick={onAim}>
          优先{AIM_LABEL[view.aim]}
        </button>
        <button type="button" className="btn-ghost" onClick={onSell}>
          出售 +{view.refund}
        </button>
        <button type="button" className="btn-ghost grow" onClick={onBack}>
          返回建塔
        </button>
      </div>
    </div>
  );
}
