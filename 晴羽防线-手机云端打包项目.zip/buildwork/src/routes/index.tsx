import { createFileRoute } from "@tanstack/react-router";
import { DefenseScreen } from "@/components/defense-screen";

export const Route = createFileRoute("/")({ component: DefenseScreen });
