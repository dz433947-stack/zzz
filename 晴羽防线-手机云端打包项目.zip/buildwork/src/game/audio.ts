let ctx: AudioContext | null = null;
let master: GainNode | null = null;
let lastShot = 0;

export function unlockAudio(): void {
  if (typeof window === "undefined") return;
  const Ctor =
    window.AudioContext ||
    (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
  if (!Ctor) return;
  if (!ctx) {
    ctx = new Ctor();
    master = ctx.createGain();
    master.gain.value = 0.16;
    master.connect(ctx.destination);
  }
  if (ctx.state === "suspended") void ctx.resume();
}

function tone(freq: number, dur: number, type: OscillatorType, gain: number, delay = 0): void {
  if (!ctx || !master) return;
  const t = ctx.currentTime + delay;
  const osc = ctx.createOscillator();
  const amp = ctx.createGain();
  osc.type = type;
  osc.frequency.setValueAtTime(freq, t);
  amp.gain.setValueAtTime(Math.max(0.0001, gain), t);
  amp.gain.exponentialRampToValueAtTime(0.0001, t + dur);
  osc.connect(amp);
  amp.connect(master);
  osc.start(t);
  osc.stop(t + dur + 0.02);
}

export function playPlace(): void {
  tone(180, 0.09, "triangle", 0.2);
  tone(320, 0.07, "sine", 0.08, 0.03);
}

export function playShoot(kind: string): void {
  const now = performance.now();
  if (now - lastShot < 60) return;
  lastShot = now;
  if (kind === "cracker") tone(140, 0.09, "triangle", 0.12);
  else if (kind === "jade") tone(920, 0.06, "sine", 0.05);
  else if (kind === "lotus") tone(640, 0.08, "triangle", 0.06);
  else tone(520, 0.05, "square", 0.04);
}

export function playHit(): void {
  tone(240, 0.04, "sine", 0.04);
}

export function playGold(): void {
  tone(880, 0.06, "sine", 0.04);
  tone(1320, 0.08, "sine", 0.03, 0.05);
}

export function playLeak(): void {
  tone(110, 0.22, "sawtooth", 0.06);
}

export function playWave(): void {
  tone(392, 0.1, "triangle", 0.07);
  tone(494, 0.1, "triangle", 0.07, 0.09);
  tone(587, 0.16, "triangle", 0.07, 0.18);
}

export function playWin(): void {
  [523, 659, 784, 1046].forEach((freq, i) => tone(freq, 0.18, "triangle", 0.07, i * 0.1));
}

export function playLose(): void {
  [392, 330, 262, 196].forEach((freq, i) => tone(freq, 0.22, "sine", 0.07, i * 0.12));
}
