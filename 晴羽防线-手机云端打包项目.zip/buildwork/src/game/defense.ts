import {
  AIM_ORDER,
  COLS,
  DAMAGE_COST,
  ENEMIES,
  MAX_RANK,
  PATH,
  PATH_LEN,
  PREP_FIRST,
  PREP_NEXT,
  RATE_COST,
  ROWS,
  SAVE_KEY,
  SELL_RATIO,
  START_GOLD,
  START_LIVES,
  TOWERS,
  WAVE_COUNT,
  WAVES,
  damageOf,
  goldScale,
  hpScale,
  isPath,
  rateOf,
  samplePath,
  type Aim,
  type EnemyKind,
  type Phase,
  type TowerKind,
} from "@/game/data";
import {
  playGold,
  playHit,
  playLeak,
  playLose,
  playPlace,
  playShoot,
  playWave,
  playWin,
} from "@/game/audio";

export interface Art {
  pig: Record<"down" | "left" | "right" | "up", HTMLImageElement[]>;
  towers: Partial<Record<TowerKind, HTMLImageElement>>;
  shots: Partial<Record<TowerKind, HTMLImageElement>>;
  impact: HTMLImageElement[];
  gate: HTMLImageElement | null;
  lantern: HTMLImageElement | null;
}

export interface TowerView {
  id: string;
  kind: TowerKind;
  name: string;
  blurb: string;
  reach: string;
  range: number;
  damage: number;
  nextDamage: number | null;
  rate: number;
  nextRate: number | null;
  dmgRank: number;
  rateRank: number;
  dmgCost: number | null;
  rateCost: number | null;
  aim: Aim;
  refund: number;
}

export interface Hud {
  phase: Phase;
  lives: number;
  gold: number;
  wave: number;
  waveCount: number;
  waveName: string;
  prepLeft: number;
  earlyBonus: number;
  enemiesLeft: number;
  kills: number;
  goldEarned: number;
  armed: TowerKind | null;
  selected: TowerView | null;
  toast: string;
  bestWave: number;
}

interface Tower {
  id: string;
  kind: TowerKind;
  c: number;
  r: number;
  x: number;
  y: number;
  dmgRank: number;
  rateRank: number;
  aim: Aim;
  cool: number;
  spent: number;
}

interface Enemy {
  id: number;
  kind: EnemyKind;
  alive: boolean;
  hp: number;
  maxHp: number;
  speed: number;
  gold: number;
  leak: number;
  dist: number;
  x: number;
  y: number;
  dx: number;
  dy: number;
  slowUntil: number;
  flash: number;
}

interface Shot {
  alive: boolean;
  kind: TowerKind;
  x: number;
  y: number;
  vx: number;
  vy: number;
  dmg: number;
  splash: number;
  slow: number;
  slowTime: number;
  target: number;
  ttl: number;
}

interface Floater {
  x: number;
  y: number;
  text: string;
  life: number;
  max: number;
  cinnabar: boolean;
}

interface Bit {
  x: number;
  y: number;
  vx: number;
  vy: number;
  life: number;
  max: number;
  color: string;
}

interface Fx {
  x: number;
  y: number;
  age: number;
}

interface Spawn {
  kind: EnemyKind;
  at: number;
}

interface Save {
  bestWave: number;
  bestKills: number;
}

const DIRS = ["down", "left", "right", "up"] as const;

function loadSave(): Save {
  if (typeof localStorage === "undefined") return { bestWave: 0, bestKills: 0 };
  try {
    const raw = localStorage.getItem(SAVE_KEY);
    if (!raw) return { bestWave: 0, bestKills: 0 };
    const parsed = JSON.parse(raw) as Partial<Save>;
    return {
      bestWave: Number(parsed.bestWave) || 0,
      bestKills: Number(parsed.bestKills) || 0,
    };
  } catch {
    return { bestWave: 0, bestKills: 0 };
  }
}

function rand(n: number): number {
  const x = Math.sin(n * 127.1 + 19.19) * 43758.5453;
  return x - Math.floor(x);
}

export class DefenseGame {
  viewW = 360;
  viewH = 520;
  dpr = 1;
  cell = 40;
  originX = 0;
  originY = 0;

  phase: Phase = "title";
  private pausedFrom: Phase = "prep";
  lives = START_LIVES;
  gold = START_GOLD;
  waveIndex = 0;
  prepLeft = PREP_FIRST;
  kills = 0;
  goldEarned = 0;
  bestWave = 0;
  bestKills = 0;
  armed: TowerKind | null = null;
  selectedId: string | null = null;
  toast = "";
  private toastLife = 0;
  private time = 0;
  private combatTime = 0;
  private shake = 0;
  private banner = "";
  private bannerLife = 0;
  private demoClock = 0;
  private nextId = 1;
  private hover: { c: number; r: number } | null = null;
  private downKey = "";
  private reduce = false;

  private towers: Tower[] = [];
  private enemies: Enemy[] = [];
  private shots: Shot[] = [];
  private floaters: Floater[] = [];
  private bits: Bit[] = [];
  private fxs: Fx[] = [];
  private spawns: Spawn[] = [];
  private spawnCursor = 0;

  private art: Art | null = null;
  private meadow: HTMLCanvasElement | null = null;
  private dirt: HTMLCanvasElement | null = null;
  private dirtPattern: CanvasPattern | null = null;
  private scratch: HTMLCanvasElement | null = null;
  private bakedKey = "";

  constructor() {
    const save = loadSave();
    this.bestWave = save.bestWave;
    this.bestKills = save.bestKills;
    if (typeof window !== "undefined" && window.matchMedia) {
      this.reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    }
  }

  attach(art: Art): void {
    this.art = art;
  }

  resize(w: number, h: number, dpr: number): void {
    this.viewW = Math.max(1, w);
    this.viewH = Math.max(1, h);
    this.dpr = dpr;
    const pad = 8;
    this.cell = Math.min((this.viewW - pad * 2) / COLS, (this.viewH - pad * 2) / ROWS);
    this.originX = (this.viewW - this.cell * COLS) / 2;
    this.originY = (this.viewH - this.cell * ROWS) / 2;
    this.dirtPattern = null;
  }

  hud(): Hud {
    const wave = this.phase === "title" ? 0 : this.waveIndex + 1;
    const selected = this.towerById(this.selectedId);
    return {
      phase: this.phase,
      lives: this.lives,
      gold: this.gold,
      wave,
      waveCount: WAVE_COUNT,
      waveName: WAVES[this.waveIndex]?.name ?? "",
      prepLeft: Math.max(0, Math.ceil(this.prepLeft)),
      earlyBonus: this.phase === "prep" || this.phase === "paused" ? Math.round(Math.max(0, this.prepLeft) * 1.5) : 0,
      enemiesLeft: this.enemies.length + Math.max(0, this.spawns.length - this.spawnCursor),
      kills: this.kills,
      goldEarned: this.goldEarned,
      armed: this.armed,
      selected: selected ? this.towerView(selected) : null,
      toast: this.toastLife > 0 ? this.toast : "",
      bestWave: this.bestWave,
    };
  }

  begin(): void {
    this.resetField();
    this.phase = "prep";
    this.waveIndex = 0;
    this.prepLeft = PREP_FIRST;
    this.say("点塔，再点草地。弯道旁边最值钱", 2.6);
  }

  restart(): void {
    this.begin();
  }

  toTitle(): void {
    this.resetField();
    this.phase = "title";
    this.armed = null;
    this.selectedId = null;
  }

  togglePause(): void {
    if (this.phase === "paused") {
      this.phase = this.pausedFrom;
      return;
    }
    if (this.phase === "prep" || this.phase === "combat") {
      this.pausedFrom = this.phase;
      this.phase = "paused";
    }
  }

  arm(kind: TowerKind): void {
    if (this.phase !== "prep" && this.phase !== "combat") return;
    this.selectedId = null;
    this.armed = this.armed === kind ? null : kind;
  }

  clearSelection(): void {
    this.selectedId = null;
    this.armed = null;
  }

  cycleAim(): void {
    const tower = this.towerById(this.selectedId);
    if (!tower) return;
    const i = AIM_ORDER.indexOf(tower.aim);
    tower.aim = AIM_ORDER[(i + 1) % AIM_ORDER.length];
  }

  upgrade(path: "damage" | "rate"): void {
    const tower = this.towerById(this.selectedId);
    if (!tower || (this.phase !== "prep" && this.phase !== "combat")) return;
    const rank = path === "damage" ? tower.dmgRank : tower.rateRank;
    const costs = path === "damage" ? DAMAGE_COST : RATE_COST;
    if (rank >= MAX_RANK) return;
    const cost = costs[rank];
    if (this.gold < cost) {
      this.say("金币不够升级", 1.2);
      return;
    }
    this.gold -= cost;
    tower.spent += cost;
    if (path === "damage") tower.dmgRank += 1;
    else tower.rateRank += 1;
  }

  sell(): void {
    const tower = this.towerById(this.selectedId);
    if (!tower || (this.phase !== "prep" && this.phase !== "combat")) return;
    const refund = Math.floor(tower.spent * SELL_RATIO);
    this.gold += refund;
    this.towers = this.towers.filter((item) => item.id !== tower.id);
    this.selectedId = null;
    this.say(`拆塔收回 ${refund}`, 1.2);
  }

  startWave(): void {
    if (this.phase !== "prep") return;
    const bonus = Math.round(Math.max(0, this.prepLeft) * 1.5);
    if (bonus > 0) {
      this.gold += bonus;
      this.goldEarned += bonus;
    }
    if (this.towers.length === 0) this.say("还没建塔，猪会直接进城", 1.6);
    else if (bonus > 0) this.say(`提前出兵 +${bonus}`, 1.3);
    this.launch();
  }

  hover(x: number, y: number): void {
    this.hover = this.cellAt(x, y);
  }

  pointerDown(x: number, y: number): void {
    const cell = this.cellAt(x, y);
    this.hover = cell;
    this.downKey = cell ? `${cell.c},${cell.r}` : "";
  }

  pointerUp(x: number, y: number): void {
    const cell = this.cellAt(x, y);
    const key = cell ? `${cell.c},${cell.r}` : "";
    if (cell && key === this.downKey) this.tap(cell.c, cell.r);
    this.downKey = "";
  }

  tick(dt: number): void {
    this.time += dt;
    if (this.toastLife > 0) this.toastLife -= dt;
    if (this.bannerLife > 0) this.bannerLife -= dt;
    if (!this.reduce) this.shake = Math.max(0, this.shake - dt * 1.6);
    this.tickBits(dt);
    this.tickFx(dt);
    this.tickFloaters(dt);

    if (this.phase === "title") {
      this.tickDemo(dt);
      return;
    }
    if (this.phase === "paused" || this.phase === "victory" || this.phase === "defeat") return;

    if (this.phase === "prep") {
      this.prepLeft -= dt;
      if (this.prepLeft <= 0) {
        this.prepLeft = 0;
        this.launch();
      }
      return;
    }

    this.combatTime += dt;
    while (this.spawnCursor < this.spawns.length && this.spawns[this.spawnCursor].at <= this.combatTime) {
      this.spawnEnemy(this.spawns[this.spawnCursor].kind, false);
      this.spawnCursor += 1;
    }
    this.moveEnemies(dt);
    if (this.phase !== "combat") return;
    this.fireTowers(dt);
    this.moveShots(dt);
    this.compact();
    if (
      this.phase === "combat" &&
      this.spawnCursor >= this.spawns.length &&
      this.enemies.length === 0
    ) {
      this.onWaveCleared();
    }
  }

  draw(ctx: CanvasRenderingContext2D): void {
    this.ensureTerrain();
    const shake = this.reduce ? 0 : (Math.random() - 0.5) * this.shake * 10;
    const shakeY = this.reduce ? 0 : (Math.random() - 0.5) * this.shake * 10;
    ctx.clearRect(0, 0, this.viewW, this.viewH);
    ctx.save();
    ctx.translate(shake, shakeY);
    this.drawMeadow(ctx);
    this.drawPath(ctx);
    this.drawPads(ctx);
    this.drawProp(ctx, this.art?.lantern ?? null, 1.05, 0.42, 0.95);
    for (const tower of this.towers) this.drawTower(ctx, tower, 1);
    this.drawGhost(ctx);
    for (const enemy of this.enemies) this.drawEnemy(ctx, enemy);
    for (const shot of this.shots) this.drawShot(ctx, shot);
    for (const fx of this.fxs) this.drawFx(ctx, fx);
    for (const bit of this.bits) this.drawBit(ctx, bit);
    this.drawProp(ctx, this.art?.gate ?? null, 1, 11.15, 1.45);
    this.drawMark(ctx, "进犯", 2.55, 0.42);
    this.drawMark(ctx, "村口", 2.35, 11.15);
    for (const floater of this.floaters) this.drawFloater(ctx, floater);
    if (this.bannerLife > 0 && this.phase !== "title") this.drawBanner(ctx);
    ctx.restore();
  }

  private resetField(): void {
    this.lives = START_LIVES;
    this.gold = START_GOLD;
    this.kills = 0;
    this.goldEarned = 0;
    this.waveIndex = 0;
    this.towers = [];
    this.enemies = [];
    this.shots = [];
    this.floaters = [];
    this.bits = [];
    this.fxs = [];
    this.spawns = [];
    this.spawnCursor = 0;
    this.armed = null;
    this.selectedId = null;
    this.banner = "";
    this.bannerLife = 0;
    this.shake = 0;
  }

  private launch(): void {
    const wave = WAVES[this.waveIndex];
    this.spawns = [];
    let at = 0.2;
    for (const group of wave.groups) {
      for (let i = 0; i < group.count; i += 1) {
        this.spawns.push({ kind: group.kind, at });
        at += group.interval;
      }
      at += 0.7;
    }
    this.spawnCursor = 0;
    this.combatTime = 0;
    this.phase = "combat";
    this.banner = wave.name;
    this.bannerLife = 1.35;
    playWave();
  }

  private onWaveCleared(): void {
    const bonus = 16 + this.waveIndex * 4;
    this.gold += bonus;
    this.goldEarned += bonus;
    if (this.waveIndex >= WAVES.length - 1) {
      this.finish("victory");
      return;
    }
    this.waveIndex += 1;
    this.phase = "prep";
    this.prepLeft = PREP_NEXT;
    this.say(`清波 +${bonus}，准备第 ${this.waveIndex + 1} 波`, 1.8);
  }

  private finish(phase: "victory" | "defeat"): void {
    if (this.phase === "victory" || this.phase === "defeat") return;
    this.phase = phase;
    this.armed = null;
    const reached = phase === "victory" ? WAVE_COUNT : this.waveIndex + 1;
    if (reached > this.bestWave) this.bestWave = reached;
    if (this.kills > this.bestKills) this.bestKills = this.kills;
    try {
      localStorage.setItem(
        SAVE_KEY,
        JSON.stringify({ bestWave: this.bestWave, bestKills: this.bestKills }),
      );
    } catch {
      /* ignore quota */
    }
    if (phase === "victory") playWin();
    else playLose();
  }

  private tap(c: number, r: number): void {
    if (this.phase !== "prep" && this.phase !== "combat") return;
    if (c < 0 || r < 0 || c >= COLS || r >= ROWS) {
      this.selectedId = null;
      return;
    }
    const occupied = this.towers.find((tower) => tower.c === c && tower.r === r);
    if (occupied) {
      this.selectedId = occupied.id;
      this.armed = null;
      return;
    }
    if (!this.armed) {
      this.selectedId = null;
      return;
    }
    this.tryPlace(c, r, this.armed);
  }

  private tryPlace(c: number, r: number, kind: TowerKind): void {
    if (isPath(c, r)) {
      this.say("田埂上不能建塔", 1.1);
      return;
    }
    const def = TOWERS[kind];
    if (this.gold < def.cost) {
      this.say("金币不够", 1.1);
      return;
    }
    this.gold -= def.cost;
    this.towers.push({
      id: `t${this.nextId++}`,
      kind,
      c,
      r,
      x: c + 0.5,
      y: r + 0.5,
      dmgRank: 0,
      rateRank: 0,
      aim: "first",
      cool: 0.35,
      spent: def.cost,
    });
    this.selectedId = null;
    playPlace();
  }

  private tickDemo(dt: number): void {
    this.demoClock -= dt;
    if (this.enemies.length < 5 && this.demoClock <= 0) {
      const kinds: EnemyKind[] = ["basic", "swift", "armored", "boss", "basic"];
      this.spawnEnemy(kinds[this.enemies.length % kinds.length], true);
      this.demoClock = 1.15;
    }
    this.moveEnemies(dt);
    this.compact();
  }

  private spawnEnemy(kind: EnemyKind, demo: boolean): void {
    const def = ENEMIES[kind];
    const scale = demo ? 1 : hpScale(this.waveIndex);
    const at = samplePath(0);
    const hp = Math.round(def.hp * (demo ? 1 : scale));
    this.enemies.push({
      id: this.nextId++,
      kind,
      alive: true,
      hp,
      maxHp: hp,
      speed: def.speed,
      gold: Math.round(def.gold * (demo ? 1 : goldScale(this.waveIndex))),
      leak: def.leak,
      dist: 0,
      x: at.x,
      y: at.y,
      dx: at.dx,
      dy: at.dy,
      slowUntil: 0,
      flash: 0,
    });
  }

  private moveEnemies(dt: number): void {
    const demo = this.phase === "title";
    for (const enemy of this.enemies) {
      if (!enemy.alive) continue;
      const slow = enemy.slowUntil > this.time ? 0.46 : 1;
      enemy.dist += enemy.speed * slow * dt;
      enemy.flash = Math.max(0, enemy.flash - dt);
      if (enemy.dist >= PATH_LEN) {
        enemy.alive = false;
        if (!demo) this.leak(enemy);
        continue;
      }
      const at = samplePath(enemy.dist);
      enemy.x = at.x;
      enemy.y = at.y;
      enemy.dx = at.dx;
      enemy.dy = at.dy;
    }
  }

  private leak(enemy: Enemy): void {
    this.lives = Math.max(0, this.lives - enemy.leak);
    this.shake = Math.min(1.2, this.shake + (enemy.kind === "boss" ? 0.9 : 0.45));
    this.float(enemy.x, enemy.y - 0.2, enemy.leak > 1 ? `-${enemy.leak} 生命` : "漏网", true);
    playLeak();
    if (this.lives <= 0) this.finish("defeat");
  }

  private fireTowers(dt: number): void {
    for (const tower of this.towers) {
      tower.cool -= dt;
      if (tower.cool > 0) continue;
      const target = this.acquire(tower);
      if (!target) continue;
      const def = TOWERS[tower.kind];
      tower.cool = 1 / rateOf(def.rate, tower.rateRank);
      const dx = target.x - tower.x;
      const dy = target.y - tower.y;
      const dist = Math.hypot(dx, dy) || 1;
      const mul = target.kind === "armored" ? def.resist : 1;
      this.shots.push({
        alive: true,
        kind: tower.kind,
        x: tower.x,
        y: tower.y - 0.12,
        vx: (dx / dist) * def.shotSpeed,
        vy: (dy / dist) * def.shotSpeed,
        dmg: damageOf(def.damage, tower.dmgRank) * mul,
        splash: def.splash,
        slow: def.slow,
        slowTime: def.slowTime,
        target: target.id,
        ttl: 1.8,
      });
      playShoot(tower.kind);
    }
  }

  private acquire(tower: Tower): Enemy | null {
    const range = TOWERS[tower.kind].range;
    const r2 = range * range;
    let best: Enemy | null = null;
    let score = 0;
    for (const enemy of this.enemies) {
      if (!enemy.alive) continue;
      const dx = enemy.x - tower.x;
      const dy = enemy.y - tower.y;
      const d2 = dx * dx + dy * dy;
      if (d2 > r2) continue;
      const next =
        tower.aim === "closest" ? -d2 : tower.aim === "strongest" ? enemy.hp : enemy.dist;
      if (!best || next > score) {
        best = enemy;
        score = next;
      }
    }
    return best;
  }

  private moveShots(dt: number): void {
    for (const shot of this.shots) {
      if (!shot.alive) continue;
      const target = this.enemyById(shot.target);
      if (target) {
        const dx = target.x - shot.x;
        const dy = target.y - shot.y;
        const dist = Math.hypot(dx, dy) || 0.0001;
        const speed = Math.hypot(shot.vx, shot.vy) || TOWERS[shot.kind].shotSpeed;
        shot.vx = (dx / dist) * speed;
        shot.vy = (dy / dist) * speed;
        if (dist < 0.3) {
          this.explode(shot, target.x, target.y, target);
          continue;
        }
      }
      shot.x += shot.vx * dt;
      shot.y += shot.vy * dt;
      shot.ttl -= dt;
      if (shot.ttl <= 0) shot.alive = false;
    }
  }

  private explode(shot: Shot, x: number, y: number, primary: Enemy | null): void {
    shot.alive = false;
    if (primary) this.hurt(primary, shot.dmg, shot.slow > 0 ? shot.slowTime : 0);
    if (shot.splash > 0) {
      const r2 = shot.splash * shot.splash;
      for (const enemy of this.enemies) {
        if (!enemy.alive || enemy.id === primary?.id) continue;
        const dx = enemy.x - x;
        const dy = enemy.y - y;
        if (dx * dx + dy * dy <= r2) this.hurt(enemy, shot.dmg, shot.slow > 0 ? shot.slowTime : 0);
      }
    }
    this.fxs.push({ x, y, age: 0 });
    this.burst(x, y, shot.kind);
    playHit();
  }

  private hurt(enemy: Enemy, amount: number, slowTime: number): void {
    if (!enemy.alive || this.phase === "title") return;
    enemy.hp -= amount;
    enemy.flash = 0.09;
    if (slowTime > 0) enemy.slowUntil = Math.max(enemy.slowUntil, this.time + slowTime);
    if (enemy.hp <= 0) {
      enemy.alive = false;
      this.gold += enemy.gold;
      this.goldEarned += enemy.gold;
      this.kills += 1;
      this.float(enemy.x, enemy.y - 0.35, `+${enemy.gold}`, false);
      playGold();
    }
  }

  private compact(): void {
    this.enemies = this.enemies.filter((enemy) => enemy.alive);
    this.shots = this.shots.filter((shot) => shot.alive);
    if (this.fxs.length > 24) this.fxs.splice(0, this.fxs.length - 24);
    if (this.bits.length > 80) this.bits.splice(0, this.bits.length - 80);
    if (this.floaters.length > 24) this.floaters.splice(0, this.floaters.length - 24);
  }

  private tickBits(dt: number): void {
    for (const bit of this.bits) {
      bit.life -= dt;
      bit.x += bit.vx * dt;
      bit.y += bit.vy * dt;
    }
    this.bits = this.bits.filter((bit) => bit.life > 0);
  }

  private tickFx(dt: number): void {
    for (const fx of this.fxs) fx.age += dt;
    this.fxs = this.fxs.filter((fx) => fx.age < 0.32);
  }

  private tickFloaters(dt: number): void {
    for (const floater of this.floaters) {
      floater.life -= dt;
      floater.y -= dt * 0.35;
    }
    this.floaters = this.floaters.filter((floater) => floater.life > 0);
  }

  private float(x: number, y: number, text: string, cinnabar = false): void {
    this.floaters.push({ x, y, text, life: 0.85, max: 0.85, cinnabar });
  }

  private burst(x: number, y: number, kind?: TowerKind): void {
    const color = kind === "jade" ? "#d7f4ff" : kind === "cracker" ? "#ffb089" : "#f6edd8";
    for (let i = 0; i < 5; i += 1) {
      const a = (Math.PI * 2 * i) / 5 + this.time;
      this.bits.push({
        x,
        y,
        vx: Math.cos(a) * 1.4,
        vy: Math.sin(a) * 1.4,
        life: 0.28,
        max: 0.28,
        color,
      });
    }
  }

  private say(text: string, life: number): void {
    this.toast = text;
    this.toastLife = life;
  }

  private cellAt(x: number, y: number): { c: number; r: number } | null {
    const c = Math.floor((x - this.originX) / this.cell);
    const r = Math.floor((y - this.originY) / this.cell);
    if (c < 0 || r < 0 || c >= COLS || r >= ROWS) return null;
    return { c, r };
  }

  private towerById(id: string | null): Tower | null {
    if (!id) return null;
    return this.towers.find((tower) => tower.id === id) ?? null;
  }

  private enemyById(id: number): Enemy | null {
    for (const enemy of this.enemies) {
      if (enemy.id === id && enemy.alive) return enemy;
    }
    return null;
  }

  private towerView(tower: Tower): TowerView {
    const def = TOWERS[tower.kind];
    const dmgMax = tower.dmgRank >= MAX_RANK;
    const rateMax = tower.rateRank >= MAX_RANK;
    return {
      id: tower.id,
      kind: tower.kind,
      name: def.name,
      blurb: def.blurb,
      reach: def.reach,
      range: def.range,
      damage: damageOf(def.damage, tower.dmgRank),
      nextDamage: dmgMax ? null : damageOf(def.damage, tower.dmgRank + 1),
      rate: rateOf(def.rate, tower.rateRank),
      nextRate: rateMax ? null : rateOf(def.rate, tower.rateRank + 1),
      dmgRank: tower.dmgRank,
      rateRank: tower.rateRank,
      dmgCost: dmgMax ? null : DAMAGE_COST[tower.dmgRank],
      rateCost: rateMax ? null : RATE_COST[tower.rateRank],
      aim: tower.aim,
      refund: Math.floor(tower.spent * SELL_RATIO),
    };
  }

  private px(x: number): number {
    return this.originX + x * this.cell;
  }

  private py(y: number): number {
    return this.originY + y * this.cell;
  }

  private ensureTerrain(): void {
    if (typeof document === "undefined") return;
    const key = `${Math.round(this.cell * 10)}`;
    if (!this.meadow) this.meadow = document.createElement("canvas");
    if (this.bakedKey !== key) {
      this.paintMeadow();
      this.paintDirt();
      this.bakedKey = key;
      this.dirtPattern = null;
    }
  }

  private paintMeadow(): void {
    const meadow = this.meadow;
    if (!meadow) return;
    const w = Math.max(2, Math.ceil(this.cell * COLS));
    const h = Math.max(2, Math.ceil(this.cell * ROWS));
    meadow.width = w;
    meadow.height = h;
    const g = meadow.getContext("2d");
    if (!g) return;
    g.fillStyle = "#2c6844";
    g.fillRect(0, 0, w, h);
    for (let i = 0; i < 90; i += 1) {
      const x = rand(i * 3 + 1) * w;
      const y = rand(i * 3 + 2) * h;
      const rw = this.cell * (0.7 + rand(i + 8) * 1.6);
      const rh = rw * (0.55 + rand(i + 9) * 0.4);
      g.fillStyle = i % 3 === 0 ? "#1f5536" : i % 3 === 1 ? "#3c8456" : "#34744c";
      g.beginPath();
      g.ellipse(x, y, rw, rh, rand(i) * Math.PI, 0, Math.PI * 2);
      g.fill();
    }
    for (let r = 0; r < ROWS; r += 1) {
      for (let c = 0; c < COLS; c += 1) {
        const n = rand(c * 17 + r * 41);
        const x = (c + 0.5) * this.cell;
        const y = (r + 0.5) * this.cell;
        if (n > 0.86) {
          g.fillStyle = n > 0.94 ? "#d7d2c4" : "#f3b6c0";
          g.beginPath();
          g.ellipse(x + (n - 0.5) * 10, y, 2.2, 2.2, 0, 0, Math.PI * 2);
          g.fill();
        } else if (n > 0.72) {
          g.strokeStyle = "#1d4d32";
          g.lineWidth = 1.2;
          g.beginPath();
          g.moveTo(x, y);
          g.lineTo(x + 3, y - 6);
          g.moveTo(x, y);
          g.lineTo(x - 4, y - 5);
          g.stroke();
        }
      }
    }
  }

  private paintDirt(): void {
    if (!this.dirt) this.dirt = document.createElement("canvas");
    const dirt = this.dirt;
    dirt.width = 128;
    dirt.height = 128;
    const g = dirt.getContext("2d");
    if (!g) return;
    g.fillStyle = "#c4a06a";
    g.fillRect(0, 0, 128, 128);
    for (let i = 0; i < 80; i += 1) {
      g.fillStyle = i % 2 ? "#b08a52" : "#d8bc86";
      g.beginPath();
      g.ellipse(rand(i + 20) * 128, rand(i + 90) * 128, 2 + rand(i) * 5, 1.5 + rand(i + 4) * 3, 0, 0, Math.PI * 2);
      g.fill();
    }
  }

  private drawMeadow(ctx: CanvasRenderingContext2D): void {
    if (!this.meadow) return;
    ctx.drawImage(this.meadow, this.originX, this.originY, this.cell * COLS, this.cell * ROWS);
  }

  private drawPath(ctx: CanvasRenderingContext2D): void {
    if (this.dirt && !this.dirtPattern) this.dirtPattern = ctx.createPattern(this.dirt, "repeat");
    const trace = () => {
      ctx.beginPath();
      for (let i = 0; i < PATH.length; i += 1) {
        const x = this.px(PATH[i][0] + 0.5);
        const y = this.py(PATH[i][1] + 0.5);
        if (i === 0) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
      }
    };
    ctx.lineCap = "round";
    ctx.lineJoin = "round";
    trace();
    ctx.strokeStyle = "#6e4a2c";
    ctx.lineWidth = this.cell * 0.78;
    ctx.stroke();
    trace();
    ctx.strokeStyle = this.dirtPattern ?? "#c4a06a";
    ctx.lineWidth = this.cell * 0.62;
    ctx.stroke();
    ctx.fillStyle = "rgba(90, 58, 28, 0.28)";
    for (let d = 0.35; d < PATH_LEN; d += 0.7) {
      const at = samplePath(d);
      ctx.beginPath();
      ctx.ellipse(this.px(at.x), this.py(at.y), this.cell * 0.05, this.cell * 0.035, 0.4, 0, Math.PI * 2);
      ctx.fill();
    }
  }

  private drawPads(ctx: CanvasRenderingContext2D): void {
    const show = this.armed || (this.towers.length === 0 && (this.phase === "prep" || this.phase === "combat"));
    if (!show) return;
    for (let r = 0; r < ROWS; r += 1) {
      for (let c = 0; c < COLS; c += 1) {
        if (isPath(c, r) || this.towers.some((tower) => tower.c === c && tower.r === r)) continue;
        ctx.beginPath();
        ctx.arc(this.px(c + 0.5), this.py(r + 0.5), this.cell * 0.16, 0, Math.PI * 2);
        ctx.fillStyle = "rgba(246, 237, 216, 0.38)";
        ctx.fill();
      }
    }
  }

  private drawGhost(ctx: CanvasRenderingContext2D): void {
    if (!this.armed || !this.hover) return;
    if (this.phase !== "prep" && this.phase !== "combat") return;
    const { c, r } = this.hover;
    const def = TOWERS[this.armed];
    const blocked = isPath(c, r) || this.towers.some((tower) => tower.c === c && tower.r === r);
    const x = c + 0.5;
    const y = r + 0.5;
    this.strokeRange(ctx, x, y, def.range, blocked ? "rgba(212,83,58,0.85)" : "rgba(228,177,90,0.9)");
    if (blocked) return;
    ctx.save();
    ctx.globalAlpha = this.gold >= def.cost ? 0.72 : 0.35;
    this.drawSprite(ctx, this.art?.towers[this.armed] ?? null, x, y, this.cell * 0.92, null);
    ctx.restore();
  }

  private drawTower(ctx: CanvasRenderingContext2D, tower: Tower, alpha: number): void {
    const selected = tower.id === this.selectedId;
    if (selected) this.strokeRange(ctx, tower.x, tower.y, TOWERS[tower.kind].range, "rgba(228,177,90,0.95)");
    ctx.save();
    ctx.globalAlpha = alpha;
    this.shadow(ctx, tower.x, tower.y + 0.22, 0.34);
    this.drawSprite(ctx, this.art?.towers[tower.kind] ?? null, tower.x, tower.y, this.cell * 0.96, null);
    const pips = tower.dmgRank + tower.rateRank;
    if (pips > 0) {
      for (let i = 0; i < pips; i += 1) {
        ctx.fillStyle = i < tower.dmgRank ? "#e4b15a" : "#d4533a";
        ctx.beginPath();
        ctx.arc(this.px(tower.x) + (i - (pips - 1) / 2) * 6, this.py(tower.y) + this.cell * 0.42, 2.2, 0, Math.PI * 2);
        ctx.fill();
      }
    }
    ctx.restore();
  }

  private drawEnemy(ctx: CanvasRenderingContext2D, enemy: Enemy): void {
    const def = ENEMIES[enemy.kind];
    let dir: (typeof DIRS)[number] = "down";
    if (Math.abs(enemy.dx) > Math.abs(enemy.dy)) dir = enemy.dx < 0 ? "left" : "right";
    else if (enemy.dy < 0) dir = "up";
    const frame = Math.floor(enemy.dist * 2.4) % 4;
    const img = this.art?.pig[dir][frame] ?? null;
    const size = this.cell * def.scale;
    this.shadow(ctx, enemy.x, enemy.y + def.scale * 0.28, def.scale * 0.28);
    if (enemy.slowUntil > this.time) {
      ctx.strokeStyle = "rgba(190, 230, 255, 0.9)";
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.arc(this.px(enemy.x), this.py(enemy.y), size * 0.42, 0, Math.PI * 2);
      ctx.stroke();
    }
    const tint =
      enemy.flash > 0
        ? "rgba(255,255,255,0.72)"
        : enemy.kind === "armored"
          ? "rgba(70, 90, 112, 0.38)"
          : enemy.kind === "swift"
            ? "rgba(255, 214, 120, 0.22)"
            : null;
    this.drawSprite(ctx, img, enemy.x, enemy.y, size, tint);
    if (!img) {
      ctx.fillStyle = "#f3b6c0";
      ctx.beginPath();
      ctx.arc(this.px(enemy.x), this.py(enemy.y), size * 0.32, 0, Math.PI * 2);
      ctx.fill();
    }
    const bw = size * 0.72;
    const bx = this.px(enemy.x) - bw / 2;
    const by = this.py(enemy.y) - size * 0.58;
    ctx.fillStyle = "rgba(16,38,28,0.55)";
    ctx.fillRect(bx, by, bw, enemy.kind === "boss" ? 6 : 4);
    const ratio = Math.max(0, enemy.hp / enemy.maxHp);
    ctx.fillStyle =
      enemy.kind === "boss" ? "#d4533a" : enemy.kind === "swift" ? "#e4b15a" : enemy.kind === "armored" ? "#d7d2c4" : "#f3b6c0";
    ctx.fillRect(bx, by, bw * ratio, enemy.kind === "boss" ? 6 : 4);
    {
      // Display the requested custom enemy name above each enemy.
      const label = "孙晴羽";
      ctx.save();
      ctx.font = `700 ${Math.max(10, Math.min(14, this.cell * 0.22))}px "Noto Sans SC", "WenQuanYi Zen Hei", sans-serif`;
      ctx.textAlign = "center";
      ctx.lineWidth = 3;
      ctx.strokeStyle = "rgba(16,38,28,0.9)";
      ctx.strokeText(label, this.px(enemy.x), by - 4);
      ctx.fillStyle = "#f6edd8";
      ctx.fillText(label, this.px(enemy.x), by - 4);
      ctx.restore();
    }
  }

  private drawShot(ctx: CanvasRenderingContext2D, shot: Shot): void {
    if (!shot.alive) return;
    const img = this.art?.shots[shot.kind] ?? null;
    const w = this.cell * (shot.kind === "cracker" ? 0.34 : 0.42);
    const h = this.cell * 0.24;
    ctx.save();
    ctx.translate(this.px(shot.x), this.py(shot.y));
    ctx.rotate(Math.atan2(shot.vy, shot.vx));
    if (img) ctx.drawImage(img, -w / 2, -h / 2, w, h);
    else {
      ctx.fillStyle = "#f6edd8";
      ctx.beginPath();
      ctx.arc(0, 0, 4, 0, Math.PI * 2);
      ctx.fill();
    }
    ctx.restore();
  }

  private drawFx(ctx: CanvasRenderingContext2D, fx: Fx): void {
    const frame = Math.min(3, Math.floor(fx.age / 0.08));
    const img = this.art?.impact[frame];
    const s = this.cell * 0.7;
    if (!img) return;
    ctx.drawImage(img, this.px(fx.x) - s / 2, this.py(fx.y) - s / 2, s, s);
  }

  private drawBit(ctx: CanvasRenderingContext2D, bit: Bit): void {
    ctx.globalAlpha = Math.max(0, bit.life / bit.max);
    ctx.fillStyle = bit.color;
    ctx.beginPath();
    ctx.arc(this.px(bit.x), this.py(bit.y), 2.4, 0, Math.PI * 2);
    ctx.fill();
    ctx.globalAlpha = 1;
  }

  private drawFloater(ctx: CanvasRenderingContext2D, floater: Floater): void {
    ctx.globalAlpha = Math.max(0, floater.life / floater.max);
    ctx.font = `700 ${Math.max(12, this.cell * 0.28)}px "Noto Sans SC", "WenQuanYi Zen Hei", sans-serif`;
    ctx.textAlign = "center";
    ctx.lineWidth = 3;
    ctx.strokeStyle = "rgba(16,38,28,0.75)";
    const x = this.px(floater.x);
    const y = this.py(floater.y);
    ctx.strokeText(floater.text, x, y);
    ctx.fillStyle = floater.cinnabar ? "#d4533a" : "#f6edd8";
    ctx.fillText(floater.text, x, y);
    ctx.globalAlpha = 1;
  }

  private drawBanner(ctx: CanvasRenderingContext2D): void {
    ctx.globalAlpha = Math.min(1, this.bannerLife * 2);
    ctx.font = `400 ${Math.max(28, this.cell * 0.7)}px "ZCOOL XiaoWei", "WenQuanYi Zen Hei", serif`;
    ctx.textAlign = "center";
    ctx.lineWidth = 6;
    ctx.strokeStyle = "rgba(16,38,28,0.55)";
    const x = this.originX + (this.cell * COLS) / 2;
    const y = this.originY + this.cell * 1.6;
    ctx.strokeText(this.banner, x, y);
    ctx.fillStyle = "#f6edd8";
    ctx.fillText(this.banner, x, y);
    ctx.globalAlpha = 1;
  }

  private drawMark(ctx: CanvasRenderingContext2D, text: string, x: number, y: number): void {
    ctx.font = `700 ${Math.max(11, this.cell * 0.24)}px "Noto Sans SC", "WenQuanYi Zen Hei", sans-serif`;
    const width = ctx.measureText(text).width + 10;
    const px = this.px(x);
    const py = this.py(y);
    ctx.fillStyle = "rgba(246,237,216,0.92)";
    ctx.beginPath();
    ctx.roundRect(px - width / 2, py - 8, width, 16, 8);
    ctx.fill();
    ctx.fillStyle = "#10261c";
    ctx.textAlign = "center";
    ctx.fillText(text, px, py + 4);
  }

  private drawProp(
    ctx: CanvasRenderingContext2D,
    img: HTMLImageElement | null,
    x: number,
    y: number,
    scale: number,
  ): void {
    if (!img) return;
    this.shadow(ctx, x, y + 0.2, scale * 0.22);
    const s = this.cell * scale;
    ctx.drawImage(img, this.px(x) - s / 2, this.py(y) - s * 0.72, s, s);
  }

  private shadow(ctx: CanvasRenderingContext2D, x: number, y: number, rx: number): void {
    ctx.fillStyle = "rgba(16, 38, 28, 0.28)";
    ctx.beginPath();
    ctx.ellipse(this.px(x), this.py(y), this.cell * rx, this.cell * rx * 0.38, 0, 0, Math.PI * 2);
    ctx.fill();
  }

  private strokeRange(ctx: CanvasRenderingContext2D, x: number, y: number, range: number, color: string): void {
    ctx.beginPath();
    ctx.arc(this.px(x), this.py(y), range * this.cell, 0, Math.PI * 2);
    ctx.fillStyle = "rgba(246, 237, 216, 0.08)";
    ctx.fill();
    ctx.strokeStyle = color;
    ctx.lineWidth = 2;
    ctx.setLineDash([6, 5]);
    ctx.stroke();
    ctx.setLineDash([]);
  }

  private drawSprite(
    ctx: CanvasRenderingContext2D,
    img: HTMLImageElement | null,
    x: number,
    y: number,
    size: number,
    tint: string | null,
  ): void {
    if (!img) return;
    const dx = this.px(x) - size / 2;
    const dy = this.py(y) - size / 2;
    if (!tint) {
      ctx.drawImage(img, dx, dy, size, size);
      return;
    }
    if (typeof document === "undefined") return;
    if (!this.scratch) this.scratch = document.createElement("canvas");
    const sw = Math.max(1, Math.ceil(size));
    const sh = sw;
    if (this.scratch.width < sw || this.scratch.height < sh) {
      this.scratch.width = Math.max(this.scratch.width, sw);
      this.scratch.height = Math.max(this.scratch.height, sh);
    }
    const sc = this.scratch.getContext("2d");
    if (!sc) return;
    sc.clearRect(0, 0, sw, sh);
    sc.globalCompositeOperation = "source-over";
    sc.globalAlpha = 1;
    sc.drawImage(img, 0, 0, sw, sh);
    sc.globalCompositeOperation = "source-atop";
    sc.fillStyle = tint;
    sc.fillRect(0, 0, sw, sh);
    ctx.drawImage(this.scratch, 0, 0, sw, sh, dx, dy, size, size);
  }
}

function loadImage(src: string): Promise<HTMLImageElement | null> {
  return new Promise((resolve) => {
    const img = new Image();
    img.crossOrigin = "anonymous";
    img.onload = () => resolve(img);
    img.onerror = () => resolve(null);
    img.src = src;
  });
}

export async function loadArt(): Promise<Art> {
  const dirs = ["down", "left", "right", "up"] as const;
  const pig = { down: [], left: [], right: [], up: [] } as Art["pig"];
  await Promise.all(
    dirs.flatMap((dir) =>
      [1, 2, 3, 4].map(async (frame, index) => {
        pig[dir][index] = (await loadImage(`/sprites/pig/${dir}-${frame}.png`)) ?? new Image();
      }),
    ),
  );
  const towers: Art["towers"] = {};
  const shots: Art["shots"] = {};
  await Promise.all(
    (Object.keys(TOWERS) as TowerKind[]).map(async (kind) => {
      towers[kind] = (await loadImage(TOWERS[kind].frame)) ?? undefined;
      shots[kind] = (await loadImage(TOWERS[kind].shot)) ?? undefined;
    }),
  );
  const impact = await Promise.all([1, 2, 3, 4].map((n) => loadImage(`/sprites/impact/impact-${n}.png`)));
  return {
    pig,
    towers,
    shots,
    impact: impact.filter((img): img is HTMLImageElement => img !== null),
    gate: await loadImage("/sprites/props/gate.png"),
    lantern: await loadImage("/sprites/props/lantern.png"),
  };
}
