export const COLS = 8;
export const ROWS = 12;
export const WAVE_COUNT = 12;
export const START_GOLD = 160;
export const START_LIVES = 20;
export const PREP_FIRST = 24;
export const PREP_NEXT = 15;
export const SELL_RATIO = 0.6;
export const MAX_RANK = 3;
export const DAMAGE_COST = [40, 75, 120];
export const RATE_COST = [35, 65, 105];
export const SAVE_KEY = "qingyu-fangxian-v1";

export type TowerKind = "bamboo" | "cracker" | "jade" | "lotus";
export type EnemyKind = "basic" | "swift" | "armored" | "boss";
export type Aim = "first" | "closest" | "strongest";
export type Phase = "title" | "prep" | "combat" | "paused" | "victory" | "defeat";

export const AIM_ORDER: Aim[] = ["first", "closest", "strongest"];
export const AIM_LABEL: Record<Aim, string> = {
  first: "最前",
  closest: "最近",
  strongest: "最强",
};

export interface TowerDef {
  kind: TowerKind;
  name: string;
  blurb: string;
  reach: string;
  cost: number;
  range: number;
  damage: number;
  rate: number;
  shotSpeed: number;
  splash: number;
  slow: number;
  slowTime: number;
  /** Damage taken by 孙晴羽·甲. */
  resist: number;
  frame: string;
  shot: string;
}

export const TOWERS: Record<TowerKind, TowerDef> = {
  bamboo: {
    kind: "bamboo",
    name: "竹弩",
    blurb: "便宜、射得快，一次打一只。",
    reach: "中程",
    cost: 50,
    range: 2.25,
    damage: 15,
    rate: 1.45,
    shotSpeed: 8.5,
    splash: 0,
    slow: 0,
    slowTime: 0,
    resist: 0.55,
    frame: "/sprites/towers/frame-1.png",
    shot: "/sprites/shots/projectile-1.png",
  },
  cracker: {
    kind: "cracker",
    name: "爆竹",
    blurb: "近处爆炸，甲猪也吃满伤害。",
    reach: "近程",
    cost: 100,
    range: 1.62,
    damage: 26,
    rate: 0.68,
    shotSpeed: 4.6,
    splash: 0.92,
    slow: 0,
    slowTime: 0,
    resist: 1,
    frame: "/sprites/towers/frame-2.png",
    shot: "/sprites/shots/projectile-2.png",
  },
  jade: {
    kind: "jade",
    name: "凝玉",
    blurb: "打中会减速，适合掐住弯道。",
    reach: "中程",
    cost: 80,
    range: 1.9,
    damage: 8,
    rate: 1,
    shotSpeed: 6.2,
    splash: 0.46,
    slow: 0.5,
    slowTime: 1.85,
    resist: 0.8,
    frame: "/sprites/towers/frame-3.png",
    shot: "/sprites/shots/projectile-3.png",
  },
  lotus: {
    kind: "lotus",
    name: "金莲",
    blurb: "打得远、打得疼，冷却很长。",
    reach: "远程",
    cost: 145,
    range: 3.2,
    damage: 50,
    rate: 0.44,
    shotSpeed: 10,
    splash: 0,
    slow: 0,
    slowTime: 0,
    resist: 0.62,
    frame: "/sprites/towers/frame-4.png",
    shot: "/sprites/shots/projectile-4.png",
  },
};

export const TOWER_LIST: TowerKind[] = ["bamboo", "cracker", "jade", "lotus"];

export interface EnemyDef {
  kind: EnemyKind;
  name: string;
  badge: string;
  hp: number;
  speed: number;
  gold: number;
  leak: number;
  scale: number;
}

export const ENEMIES: Record<EnemyKind, EnemyDef> = {
  basic: { kind: "basic", name: "孙晴羽", badge: "", hp: 36, speed: 1.18, gold: 8, leak: 1, scale: 0.92 },
  swift: { kind: "swift", name: "孙晴羽·疾", badge: "疾", hp: 24, speed: 2.05, gold: 10, leak: 1, scale: 0.74 },
  armored: { kind: "armored", name: "孙晴羽·甲", badge: "甲", hp: 118, speed: 0.74, gold: 18, leak: 1, scale: 1 },
  boss: { kind: "boss", name: "孙晴羽·王", badge: "王", hp: 680, speed: 0.48, gold: 80, leak: 4, scale: 1.5 },
};

export interface WaveGroup {
  kind: EnemyKind;
  count: number;
  interval: number;
}

export interface WaveDef {
  name: string;
  groups: WaveGroup[];
}

export const WAVES: WaveDef[] = [
  { name: "散猪", groups: [{ kind: "basic", count: 8, interval: 0.9 }] },
  { name: "列队", groups: [{ kind: "basic", count: 12, interval: 0.7 }] },
  { name: "小跑", groups: [{ kind: "basic", count: 6, interval: 0.65 }, { kind: "swift", count: 6, interval: 0.48 }] },
  { name: "疾奔", groups: [{ kind: "swift", count: 14, interval: 0.36 }] },
  { name: "披甲", groups: [{ kind: "armored", count: 5, interval: 1.1 }, { kind: "basic", count: 8, interval: 0.5 }] },
  { name: "混编", groups: [{ kind: "basic", count: 10, interval: 0.4 }, { kind: "swift", count: 8, interval: 0.34 }] },
  { name: "铁蹄", groups: [{ kind: "armored", count: 7, interval: 0.85 }, { kind: "swift", count: 8, interval: 0.38 }] },
  { name: "猪王", groups: [{ kind: "boss", count: 1, interval: 0.4 }, { kind: "basic", count: 8, interval: 0.48 }] },
  { name: "合围", groups: [{ kind: "armored", count: 8, interval: 0.7 }, { kind: "swift", count: 10, interval: 0.3 }] },
  { name: "奔袭", groups: [{ kind: "swift", count: 18, interval: 0.24 }, { kind: "armored", count: 5, interval: 0.8 }] },
  { name: "厚阵", groups: [{ kind: "armored", count: 10, interval: 0.55 }, { kind: "basic", count: 12, interval: 0.28 }] },
  {
    name: "终章",
    groups: [
      { kind: "boss", count: 2, interval: 4.2 },
      { kind: "armored", count: 6, interval: 0.6 },
      { kind: "swift", count: 8, interval: 0.3 },
    ],
  },
];

/** Orthogonal trail from the field edge to the village gate. Each step is one cell. */
export const PATH: ReadonlyArray<readonly [number, number]> = [
  [1, 0],
  [1, 1],
  [1, 2],
  [1, 3],
  [2, 3],
  [3, 3],
  [4, 3],
  [5, 3],
  [6, 3],
  [6, 4],
  [6, 5],
  [5, 5],
  [4, 5],
  [3, 5],
  [2, 5],
  [2, 6],
  [2, 7],
  [2, 8],
  [3, 8],
  [4, 8],
  [5, 8],
  [6, 8],
  [6, 9],
  [6, 10],
  [5, 10],
  [4, 10],
  [3, 10],
  [2, 10],
  [1, 10],
  [1, 11],
];

export const PATH_LEN = PATH.length - 1;

const PATH_KEYS = new Set(PATH.map(([c, r]) => `${c},${r}`));

export function isPath(c: number, r: number): boolean {
  return PATH_KEYS.has(`${c},${r}`);
}

export interface PathSample {
  x: number;
  y: number;
  dx: number;
  dy: number;
}

export function samplePath(dist: number): PathSample {
  const max = PATH.length - 1;
  const d = Math.max(0, Math.min(PATH_LEN, dist));
  let i = Math.floor(d);
  if (i >= max) i = max - 1;
  const t = d - i;
  const a = PATH[i];
  const b = PATH[i + 1];
  return {
    x: a[0] + 0.5 + (b[0] - a[0]) * t,
    y: a[1] + 0.5 + (b[1] - a[1]) * t,
    dx: b[0] - a[0],
    dy: b[1] - a[1],
  };
}

export function damageOf(base: number, rank: number): number {
  return Math.round(base * (1 + rank * 0.5));
}

export function rateOf(base: number, rank: number): number {
  return base * (1 + rank * 0.38);
}

export function hpScale(waveIndex: number): number {
  return 1 + waveIndex * 0.12;
}

export function goldScale(waveIndex: number): number {
  return 1 + waveIndex * 0.06;
}
